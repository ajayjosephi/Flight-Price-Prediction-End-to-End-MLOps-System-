-- Active: 1759519351339@@127.0.0.1@5432@predictions


CREATE TABLE IF NOT EXISTS public.predictions (
    id SERIAL PRIMARY KEY,
    airline TEXT,
    flight TEXT,
    source_city TEXT,
    departure_time TEXT,
    stops TEXT,
    arrival_time TEXT,
    destination_city TEXT,
    class TEXT,
    duration DOUBLE PRECISION,
    days_left INTEGER,
    predicted_price DOUBLE PRECISION,
    prediction_confidence DOUBLE PRECISION,
    source TEXT,
    prediction_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    actual_price DOUBLE PRECISION
);

    -- Model Output
      predicted_price DOUBLE PRECISION NOT NULL,
    prediction_confidence DOUBLE PRECISION NOT NULL,

    -- Actual for evaluation (optional)
    actual_price DOUBLE PRECISION
);
    
    
    -- Model Output
    predicted_churn INTEGER NOT NULL, 
    prediction_confidence FLOAT, 
    actual_label INTEGER ;

CREATE TABLE IF NOT EXISTS processed_files (
    id SERIAL PRIMARY KEY,
    filename VARCHAR(255) UNIQUE NOT NULL,
    processed_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

