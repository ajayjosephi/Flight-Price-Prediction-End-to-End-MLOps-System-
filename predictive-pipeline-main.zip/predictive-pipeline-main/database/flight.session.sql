-- Active: 1759519351339@@127.0.0.1@5432@predictions


CREATE TABLE predictions (
    id SERIAL PRIMARY KEY,
    prediction_date TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    source VARCHAR(50),

    -- Input Columns
    airline TEXT,
    flight TEXT,
    source_city TEXT,
    departure_time TEXT,
    stops TEXT,
    arrival_time TEXT,
    destination_city TEXT,
    class TEXT,
    duration DOUBLE PRECISION,
    days_left INTEGER,

    -- Model Output
      predicted_price DOUBLE PRECISION NOT NULL,
    prediction_confidence DOUBLE PRECISION NOT NULL,

    -- Actual for evaluation (optional)
    actual_price DOUBLE PRECISION
);
    
    
    -- Model Output
    predicted_churn INTEGER NOT NULL, 
    prediction_confidence FLOAT, 
    actual_label INTEGER ;

CREATE TABLE IF NOT EXISTS processed_files (
    id SERIAL PRIMARY KEY,
    filename VARCHAR(255) UNIQUE NOT NULL,
    processed_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);




CREATE TABLE IF NOT EXISTS validation_statistics (
    id SERIAL PRIMARY KEY,
    filepath TEXT,
    total_rows INTEGER,
    valid_rows INTEGER,
    invalid_rows INTEGER,
    criticality VARCHAR(20),
    errors_summary TEXT,
    error_counts JSONB,
    created_on TIMESTAMP,
    bad_row_indices TEXT
);


-- Training data table (for Grafana model drift analysis)
CREATE TABLE IF NOT EXISTS training_data (
    id SERIAL PRIMARY KEY,
    airline TEXT,
    flight TEXT,
    source_city TEXT,
    departure_time TEXT,
    stops TEXT,
    arrival_time TEXT,
    destination_city TEXT,
    class TEXT,
    duration DOUBLE PRECISION,
    days_left INTEGER,
    price DOUBLE PRECISION 
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP 
);