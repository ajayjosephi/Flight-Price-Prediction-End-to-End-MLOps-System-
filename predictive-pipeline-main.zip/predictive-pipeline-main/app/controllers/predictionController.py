from fastapi import APIRouter, BackgroundTasks, Header, Response, HTTPException
from pydantic import BaseModel
from typing import List
from datetime import datetime, date, time
import pytz
import pandas as pd

from businessLogic.predictionBL import make_prediction
from databaseLogic.predictionDL import fetch_past_predictions

router = APIRouter(
    prefix="/predict",
    tags=["prediction"],
)

class PredictionRequest(BaseModel):
    data: List[dict]

@router.post("/")
def predict(
    request: PredictionRequest,
    background_tasks: BackgroundTasks,
    x_request_source: str = Header(default="Streamlit_Webapp")
):
    df = pd.DataFrame(request.data)
    csv_output = make_prediction(df, x_request_source, background_tasks)
    # if x_request_source == "Scheduled":
    #     return {
    #         "status": "success",
    #         "num_predictions": len(df),
    #         "source": x_request_source,
    #     }
    return Response(content=csv_output, media_type="text/csv")


@router.get("/past_predictions")
def get_past_predictions(start_date: date, end_date: date, source: str):
    valid_sources = ["WebApp", "Scheduled Predictions", "All"]
    source_map = {
        "WebApp": "Streamlit_Webapp",
        "Scheduled Predictions": "Scheduled",
        "All": None
    }

    if source not in valid_sources:
        raise HTTPException(status_code=400, detail="Invalid source filter.")

    tz = pytz.UTC
    start = datetime.combine(start_date, time.min).astimezone(tz)
    end = datetime.combine(end_date, time.max).astimezone(tz)

    results = fetch_past_predictions(start, end, source_map[source])
    if not results:
        raise HTTPException(status_code=404, detail="No predictions found.")

    return {"records": results, "total": len(results)}
