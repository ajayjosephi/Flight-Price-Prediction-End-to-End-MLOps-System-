from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.exceptions import AirflowSkipException

from datetime import datetime, timedelta
import os
import time
import requests
import pandas as pd


# CONFIG 
GOOD_DATA_FOLDER = "/opt/airflow/data/good_data"
POSTGRES_CONN_ID = "processed_files"

#   FIXED: Correct FastAPI prediction endpoint
PREDICTION_API_URL = "http://fastapi_service:8000/api/predict/"


#  HELPERS 
def get_processed_files():
    """
    Ensure processed_files table exists and return set of filenames
    already processed.
    """
    pg_hook = PostgresHook(postgres_conn_id=POSTGRES_CONN_ID)
    conn = pg_hook.get_conn()
    cursor = conn.cursor()

    # Create table if it doesn't exist
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS processed_files (
            filename TEXT PRIMARY KEY,
            processed_date TIMESTAMP
        );
        """
    )
    conn.commit()  #   commit DDL so table actually exists

    cursor.execute("SELECT filename FROM processed_files;")
    processed_files = {row[0] for row in cursor.fetchall()}

    cursor.close()
    conn.close()
    return processed_files



def check_for_new_data():
    if not os.path.exists(GOOD_DATA_FOLDER):
        raise AirflowSkipException(f"Folder '{GOOD_DATA_FOLDER}' does not exist.")

    processed_files = get_processed_files()
    all_files = set(os.listdir(GOOD_DATA_FOLDER))

    if not all_files:
        raise AirflowSkipException("No files found in the 'good-data' folder.")

    new_files = list(all_files - processed_files)

    if not new_files:
        raise AirflowSkipException("No new files to process.")

    print(f"Found new files: {new_files}")
    return new_files

MAX_API_RETRIES = 3
RETRY_DELAY = 10

def save_processed_files(file_names):
    if not file_names:
        return

    pg_hook = PostgresHook(postgres_conn_id=POSTGRES_CONN_ID)
    conn = pg_hook.get_conn()
    cursor = conn.cursor()

    for filename in file_names:
        cursor.execute(
            """
            INSERT INTO processed_files (filename, processed_date)
            VALUES (%s, NOW())
            ON CONFLICT (filename) DO NOTHING;
            """,
            (filename,),
        )

    conn.commit()
    cursor.close()
    conn.close()
    print(f"Saved processed files: {file_names}")


#  UPDATED PREDICTION TASK 
def make_predictions(**_):
    task_instance = _["task_instance"]
    new_files = task_instance.xcom_pull(task_ids="check_for_new_data")

    if not new_files:
        return "No new data for predictions"

    predictions_results = []
    successfully_processed_files = []

    for file_name in new_files:
        file_path = os.path.join(GOOD_DATA_FOLDER, file_name)
        print(f"\n--- Processing file: {file_path} ---")

        try:
            df = pd.read_csv(file_path)
            print(f"Read file OK: {file_name}")

            required_columns = [
                "airline", "flight", "source_city", "departure_time", "stops",
                "arrival_time", "destination_city", "class", "duration",
                "days_left"
            ]
            missing_columns = [c for c in required_columns if c not in df.columns]

            if missing_columns:
                print(f"Missing required columns: {missing_columns}")
                continue

            # Drop unnecessary columns if present
            df = df.drop(columns=[col for col in ["Unnamed: 0", "price"] if col in df.columns])

            data_payload = df.to_dict(orient="records")

            if not data_payload:
                print(f" File {file_name} contains no valid rows. Skipping.")
                continue

            try:
                response = requests.post(
                    PREDICTION_API_URL,
                    json={"data": data_payload},
                    headers={"x-request-source": "Scheduled"},
                    timeout=60,
                )
                response.raise_for_status()  # FAILS if 4xx/5xx
                print(f"Prediction success for: {file_name}")

            except requests.exceptions.RequestException as api_err:
                print(f" API error for {file_name}: {api_err}")
                continue

            # predictions_results.append(response.json())
            successfully_processed_files.append(file_name)

        except pd.errors.EmptyDataError:
            print(f"Empty or corrupted CSV: {file_name}")
            continue
        except Exception as e:
            print(f" Unexpected error for {file_name}: {e}")
            continue

    save_processed_files(successfully_processed_files)

    return f"Predictions made for {len(successfully_processed_files)} files"


#  DAG DEFINITION 
default_args = {
    "owner": "airflow",
    "start_date": datetime(2025, 1, 1),
    "retries": 0,
    "retry_delay": timedelta(minutes=1),
}

dag = DAG(
    "prediction_dag",
    description="Automated prediction job for flight price model",
    schedule_interval=timedelta(minutes=2),
    default_args=default_args,
    catchup=False,
    tags=["ml-pipeline", "predictions"],
)

check_data_task = PythonOperator(
    task_id="check_for_new_data",
    python_callable=check_for_new_data,
    provide_context=True,
    dag=dag,
)

predict_task = PythonOperator(
    task_id="make_predictions",
    python_callable=make_predictions,
    provide_context=True,
    dag=dag,
)

check_data_task >> predict_task
