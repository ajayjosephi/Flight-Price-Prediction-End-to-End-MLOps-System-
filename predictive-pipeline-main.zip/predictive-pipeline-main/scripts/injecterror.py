# inject_errors_flight.py

import pandas as pd
import numpy as np
import random
import os
from pathlib import Path

# Configuration
SOURCE_FILE = "data/flightPricePrediction.csv"

ERROR_OUTPUT_FOLDER = "airflow/data/error_data"
NUM_ERROR_FILES = 1000          
ROWS_PER_FILE = 100             
Path(ERROR_OUTPUT_FOLDER).mkdir(parents=True, exist_ok=True)

# Existing error functions
def insert_numeric_as_string(df, col, percentage=0.05):
    n = max(1, int(len(df) * percentage))
    idx = random.sample(range(len(df)), n)
    df.loc[idx, col] = random.choice(["abc", "###", "12x", "??", "NaNa"])
    return df

def insert_special_characters(df, col, percentage=0.05):
    n = max(1, int(len(df) * percentage))
    idx = random.sample(range(len(df)), n)
    df.loc[idx, col] = random.choice(['&&%', '#()^', '~!!', '??=', '$$$'])
    return df

def corrupt_flight_class(df):
    wrong = ["123", "!!", "firsttt", "busines$", "eccc", "None"]
    n = max(1, int(len(df) * 0.05))
    idx = random.sample(range(len(df)), n)
    df.loc[idx, "class"] = random.choices(wrong, k=n)
    return df

def corrupt_days_left(df):
    wrong = ["-10", "9999", "abc", "??", "NaN"]
    n = max(1, int(len(df) * 0.05))
    idx = random.sample(range(len(df)), n)
    df.loc[idx, "days_left"] = wrong[0] 
    return df

def insert_random_nan(df, col, pct=0.05):
    n = max(1, int(len(df) * pct))
    idx = random.sample(range(len(df)), n)
    df.loc[idx, col] = np.nan
    return df

def shuffle_column_values(df, col, pct=0.1):
    n = max(1, int(len(df) * pct))
    idx = random.sample(range(len(df)), n)

    shuffled = df.loc[idx, col].sample(frac=1).values
    df.loc[idx, col] = shuffled

    print(f"Shuffled wrong values in column: {col}")
    return df

def inject_out_of_range(df):
    n = max(1, int(len(df) * 0.05))
    idx = random.sample(range(len(df)), n)

    df.loc[idx, "duration"] = random.choice([9999, -5, 2000])
    df.loc[idx, "price"] = random.choice([-100, 999999, 0])

    print("Injected out-of-range values in duration & price")
    return df

# Main logic
df_original = pd.read_csv(SOURCE_FILE)

for i in range(1, NUM_ERROR_FILES + 1):

    print(f"\n--- Generating file {i}/{NUM_ERROR_FILES} ---")

    #    Rows can repeat across different files, which is fine.
    df = df_original.sample(n=ROWS_PER_FILE, replace=False).reset_index(drop=True)

    # Apply your error injections on this 100-row subset
    df = insert_random_nan(df, "duration")
    df = insert_random_nan(df, "days_left")

    df = insert_numeric_as_string(df, "arrival_time")
    df = insert_numeric_as_string(df, "destination_city")

    df = insert_special_characters(df, "destination_city")

    df = corrupt_flight_class(df)
    df = corrupt_days_left(df)

    df = shuffle_column_values(df, "arrival_time", pct=0.07)

    df = inject_out_of_range(df)

    output_path = os.path.join(
        ERROR_OUTPUT_FOLDER,
        f"flight_data_with_errors_{i:04d}.csv" 
    )
    df.to_csv(output_path, index=False)

    print(f"Saved → {output_path}")

print("\nError generation complete → airflow/data/error_data/")
