# app/databaseLogic/predictionDL.py

import logging
from datetime import datetime

import pytz
from psycopg2 import DatabaseError
from fastapi import HTTPException

from helpers.dbconfig import get_connection, release_connection


def insert_predictions(df, predictions, confidences, source, actual_prices=None):
    """
    Inserts flight price predictions into the database.
    """
    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor()

        #  DEBUG: where are we actually connected?
        try:
            cursor.execute("SELECT current_database(), current_user, current_schema()")
            db_name, db_user, db_schema = cursor.fetchone()
            logging.info(f"DB debug: db={db_name}, user={db_user}, schema={db_schema}")

            cursor.execute(
                """
                SELECT table_schema, table_name
                FROM information_schema.tables
                WHERE table_name = 'predictions'
                """
            )
            table_rows = cursor.fetchall()
            logging.info(f"Table lookup for 'predictions': {table_rows}")
        except Exception as dbg_e:
            logging.warning(f"DB debug queries failed: {dbg_e}")

        now = datetime.now(pytz.UTC)
        confidences = [float(c) for c in confidences]
        df = df.reset_index(drop=True)

        data = [
            (
                row["airline"],
                row["flight"],
                row["source_city"],
                row["departure_time"],
                row["stops"],
                row["arrival_time"],
                row["destination_city"],
                row["class"],
                float(row["duration"]),
                int(row["days_left"]),
                float(predictions[i]),  # predicted price
                confidences[i],
                source,
                now,
                float(actual_prices[i]) if actual_prices is not None else None,
            )
            for i, row in df.iterrows()
        ]

        cursor.executemany(
            """
            INSERT INTO public.predictions
            (airline, flight, source_city, departure_time, stops, arrival_time,
             destination_city, class, duration, days_left,
             predicted_price, prediction_confidence, source, prediction_date, actual_price)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            data,
        )

        connection.commit()
        logging.info(
            "Inserted %d flight price predictions from source=%s",
            len(df),
            source,
        )

    except DatabaseError as e:
        logging.error(f"Database insertion error: {e}")
        if connection:
            connection.rollback()
        raise HTTPException(
            status_code=500,
            detail="Error saving flight price predictions to the database.",
        )
    finally:
        if cursor:
            cursor.close()
        if connection:
            release_connection(connection)


def fetch_past_predictions(start_date, end_date, db_source):
    """
    Fetch flight price predictions from the database for a given date range and source.
    """
    connection = None
    cursor = None
    try:
        connection = get_connection()
        cursor = connection.cursor()

        query = """
            SELECT *
            FROM public.predictions
            WHERE prediction_date BETWEEN %s AND %s
        """
        params = [start_date, end_date]

        if db_source:
            query += " AND source = %s"
            params.append(db_source)

        query += " ORDER BY prediction_date DESC"

        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]

        results = [dict(zip(columns, row)) for row in rows]
        logging.info(
            "Fetched %d past predictions from %s to %s (source=%s)",
            len(results),
            start_date,
            end_date,
            db_source or "ALL",
        )
        return results

    except Exception as e:
        logging.error(f"Error fetching flight predictions: {e}")
        raise HTTPException(
            status_code=500,
            detail="Error fetching flight predictions.",
        )
    finally:
        if cursor:
            cursor.close()
        if connection:
            release_connection(connection)
