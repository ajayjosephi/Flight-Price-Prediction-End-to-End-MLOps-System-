#necessary imports
import os
from psycopg2 import pool
from fastapi import HTTPException

# DB connection pool 
db_pool = None

def get_db_pool():
    """Lazy initialization of connection pool"""
    global db_pool
    if db_pool is None:
        try:
            db_pool = pool.SimpleConnectionPool(
                minconn=1,
                maxconn=10,
                user=os.getenv("POSTGRES_USER", "Visali"),
                password=os.getenv("POSTGRES_PASSWORD", "epita25"),
                host=os.getenv("DB_HOST", "host.docker.internal"),
                port=os.getenv("DB_PORT", "5432"),        
                database=os.getenv("POSTGRES_DB", "predictions"),

            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error connecting to DB: {str(e)}")
    return db_pool

def get_connection():
    """Get a connection from the pool"""
    pool_instance = get_db_pool()
    try:
        conn = pool_instance.getconn()
        if not conn:
            raise HTTPException(status_code=500, detail="Failed to get DB connection")
        return conn
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB connection error: {str(e)}")

def release_connection(conn):
    """Release the connection back to the pool"""
    if db_pool and conn:
        db_pool.putconn(conn)