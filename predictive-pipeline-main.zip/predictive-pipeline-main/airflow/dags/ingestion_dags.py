import os
import random
from datetime import datetime, timedelta
from airflow.decorators import dag, task
from airflow.utils.dates import days_ago
from airflow.exceptions import AirflowFailException, AirflowSkipException
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
import json
import logging
import glob
import requests
import urllib.parse  # needed for send_alerts report URL

# Constants and paths
PROJECT_ROOT = "/opt/airflow"
RAW_DATA_DIR = os.path.join(PROJECT_ROOT, "data", "raw_data")
GOOD_DATA_DIR = os.path.join(PROJECT_ROOT, "data", "good_data")
BAD_DATA_DIR = os.path.join(PROJECT_ROOT, "data", "bad_data")
POSTGRES_CONN_ID = "processed_files"

# GE folder is still needed for reports + optional validation
GE_DATA_CONTEXT_ROOT = "/airflow/great_expectations"
GE_PATH = os.path.join(PROJECT_ROOT, "great_expectations")

SUITE_NAME = "flight_data_suite"


@dag(
    dag_id="_ingestion_dag",
    description="Flight price data ingestion and validation pipeline",
    schedule_interval=timedelta(minutes=1),
    start_date=days_ago(1),
    catchup=False,
    max_active_runs=1,
    tags=["flight", "validation", "data-quality"],
)
def _ingestion_dag():

    # 1. Read file
    @task(task_id="read_data")
    def read_data() -> str:
        files = [f for f in os.listdir(RAW_DATA_DIR) if f.endswith(".csv")]
        if not files:
            raise AirflowSkipException("No CSV files found in raw-data folder")
        return os.path.join(RAW_DATA_DIR, random.choice(files))

    # 2. Validate data
    @task(task_id="validate_data")
    def validate_data(filepath: str) -> dict:
        import pandas as pd
        import re

        try:
            print(f"Validating file: {filepath}")
            df = pd.read_csv(filepath)
            total_rows = len(df)
            print("Total rows:", total_rows)

          
            ge_success = None
            try:
                # Lazy import so DAG doesn't crash if GE isn't installed
                from great_expectations.data_context import FileDataContext

                # This should match your mounted GE context:
                # ./airflow/great_expectations -> /opt/airflow/great_expectations
                context = FileDataContext(context_root_dir=GE_PATH)

                # Runtime batch request for this one file
                # Make sure datasource/data_connector names exist in your GE config
                batch_request = {
                    "datasource_name": "flight_runtime_datasource",
                    "data_connector_name": "runtime_data_connector",
                    "data_asset_name": os.path.basename(filepath),
                    "runtime_parameters": {"path": filepath},
                    "batch_identifiers": {
                        "default_identifier_name": os.path.basename(filepath)
                    },
                }

                validator = context.get_validator(
                    batch_request=batch_request,
                    expectation_suite_name=SUITE_NAME,
                )

                ge_result = validator.validate()
                ge_success = ge_result.success

                # Build Data Docs (HTML) for Teams link
                context.build_data_docs()
                print(f"GE validation completed. success={ge_success}")

            except Exception as ge_err:
                # Do NOT break the DAG if GE is misconfigured – just log it.
                logging.warning(
                    f"Great Expectations validation skipped or failed: {ge_err}"
                )
                ge_success = None

        

            # 1. Schema / required columns
            required_columns = [
                "airline",
                "departure_time",
                "arrival_time",
                "source_city",
                "destination_city",
                "class",
                "duration",
                "days_left",
                "price",
            ]

            missing_columns = [c for c in required_columns if c not in df.columns]

            if missing_columns:
                # Treat as data failure, not code failure
                bad_row_indices = list(range(total_rows))
                results = {
                    "filepath": filepath,
                    "total_rows": total_rows,
                    "valid_rows": 0,
                    "invalid_rows": total_rows,
                    "criticality": "high",
                    "errors_summary": f"Missing required columns: {missing_columns}",
                    "error_counts": {
                        "missing_columns": len(missing_columns),
                        "missing_columns_list": missing_columns,
                    },
                    "created_on": datetime.now().isoformat(),
                    "bad_row_indices": bad_row_indices,
                    "validation_status": "FAILED_SCHEMA",
                    "error_ratio": 1.0,
                    "ge_success": ge_success,
                }
                print("Schema validation failed:", results)
                return results

            # 2. Base quality checks: missing values & duplicates
            missing_values = df.isnull().sum()
            duplicate_count = int(df.duplicated().sum())

            bad_row_indices = set()

            # rows with any missing
            if missing_values.sum() > 0:
                bad_row_indices.update(df[df.isnull().any(axis=1)].index.tolist())

            # duplicate rows
            if duplicate_count > 0:
                bad_row_indices.update(df[df.duplicated()].index.tolist())

            # 3. Convert numeric columns safely
            price_numeric = pd.to_numeric(df["price"], errors="coerce")
            duration_numeric = pd.to_numeric(df["duration"], errors="coerce")
            days_left_numeric = pd.to_numeric(df["days_left"], errors="coerce")

            # 4. Price checks (matches error-generation)
            price_non_numeric = int(price_numeric.isna().sum())
            price_negative = int((price_numeric < 0).sum())
            price_zero = int((price_numeric == 0).sum())
            # out-of-range: very large (we injected 999999)
            price_out_of_range = int((price_numeric > 500000).sum())

            bad_row_indices.update(price_numeric[price_numeric.isna()].index.tolist())
            bad_row_indices.update(price_numeric[price_numeric < 0].index.tolist())
            bad_row_indices.update(price_numeric[price_numeric == 0].index.tolist())
            bad_row_indices.update(price_numeric[price_numeric > 500000].index.tolist())

            # 5. Duration checks
            duration_non_numeric = int(duration_numeric.isna().sum())
            duration_non_positive = int((duration_numeric <= 0).sum())
            duration_out_of_range = int((duration_numeric > 72).sum())  # >72 hours

            bad_row_indices.update(duration_numeric[duration_numeric.isna()].index.tolist())
            bad_row_indices.update(duration_numeric[duration_numeric <= 0].index.tolist())
            bad_row_indices.update(duration_numeric[duration_numeric > 72].index.tolist())

            # 6. days_left checks
            days_left_non_numeric = int(days_left_numeric.isna().sum())
            days_left_negative = int((days_left_numeric < 0).sum())

            bad_row_indices.update(days_left_numeric[days_left_numeric.isna()].index.tolist())
            bad_row_indices.update(days_left_numeric[days_left_numeric < 0].index.tolist())

            # 7. arrival_time / destination_city numeric junk + special chars
            # numeric-like strings (we injected numeric into these)
            def is_numeric_like_series(s: pd.Series) -> pd.Series:
                return s.astype(str).str.fullmatch(r"\d+(\.\d+)?", na=False)

            arrival_numeric_like = is_numeric_like_series(df["arrival_time"])
            dest_numeric_like = is_numeric_like_series(df["destination_city"])

            arrival_numeric_like_count = int(arrival_numeric_like.sum())
            dest_numeric_like_count = int(dest_numeric_like.sum())

            bad_row_indices.update(df[arrival_numeric_like].index.tolist())
            bad_row_indices.update(df[dest_numeric_like].index.tolist())

            # destination_city consisting mainly of special characters
            dest_special = df["destination_city"].astype(str).str.fullmatch(
                r"[^A-Za-z0-9 ]+", na=False
            )
            dest_special_count = int(dest_special.sum())
            bad_row_indices.update(df[dest_special].index.tolist())

            # 8. Invalid class labels
            # expected values from original dataset
            expected_classes = {"Economy", "Business", "Premium_Economy"}
            class_invalid_mask = ~df["class"].isin(expected_classes)
            class_invalid_count = int(class_invalid_mask.sum())

            bad_row_indices.update(df[class_invalid_mask].index.tolist())

            # 9. Build error summary & metrics
            bad_row_indices = sorted(list(bad_row_indices))
            invalid_rows = len(bad_row_indices)
            valid_rows = total_rows - invalid_rows

            # ERROR RATIO + NEW THRESHOLDS
            error_ratio = invalid_rows / total_rows if total_rows > 0 else 0.0

            # Business-driven thresholds:
            # 0 or <5% -> low, 5–20% -> medium, >=20% -> high
            if error_ratio == 0:
                criticality = "low"
            elif error_ratio < 0.05:
                criticality = "low"
            elif error_ratio < 0.2:
                criticality = "medium"
            else:
                criticality = "high"

            # Human-readable error summary
            errors = []
            # missing counts per column
            for col, count in missing_values.items():
                if count > 0:
                    errors.append(f"{col}: {int(count)} missing values")
            if duplicate_count > 0:
                errors.append(f"Duplicate rows: {duplicate_count}")
            if price_non_numeric > 0:
                errors.append(f"price: {price_non_numeric} non-numeric values")
            if price_negative > 0:
                errors.append(f"price: {price_negative} negative values")
            if price_zero > 0:
                errors.append(f"price: {price_zero} zero values")
            if price_out_of_range > 0:
                errors.append(
                    f"price: {price_out_of_range} out-of-range values (>500000)"
                )
            if duration_non_numeric > 0:
                errors.append(f"duration: {duration_non_numeric} non-numeric values")
            if duration_non_positive > 0:
                errors.append(
                    f"duration: {duration_non_positive} <=0 values"
                )
            if duration_out_of_range > 0:
                errors.append(
                    f"duration: {duration_out_of_range} out-of-range values (>72h)"
                )
            if days_left_non_numeric > 0:
                errors.append(
                    f"days_left: {days_left_non_numeric} non-numeric values"
                )
            if days_left_negative > 0:
                errors.append(
                    f"days_left: {days_left_negative} negative values"
                )
            if arrival_numeric_like_count > 0:
                errors.append(
                    f"arrival_time: {arrival_numeric_like_count} numeric-like junk values"
                )
            if dest_numeric_like_count > 0:
                errors.append(
                    f"destination_city: {dest_numeric_like_count} numeric-like junk values"
                )
            if dest_special_count > 0:
                errors.append(
                    f"destination_city: {dest_special_count} special-character values"
                )
            if class_invalid_count > 0:
                errors.append(f"class: {class_invalid_count} invalid labels")

            errors_summary = "; ".join(errors) if errors else "No issues found"

            error_counts = {
                # base missing + duplicates
                **{f"{col}_missing": int(cnt) for col, cnt in missing_values.items()},
                "duplicate_rows": duplicate_count,
                # price
                "price_non_numeric": price_non_numeric,
                "price_negative": price_negative,
                "price_zero": price_zero,
                "price_out_of_range": price_out_of_range,
                # duration
                "duration_non_numeric": duration_non_numeric,
                "duration_non_positive": duration_non_positive,
                "duration_out_of_range": duration_out_of_range,
                # days_left
                "days_left_non_numeric": days_left_non_numeric,
                "days_left_negative": days_left_negative,
                # arrival/destination
                "arrival_time_numeric_like": arrival_numeric_like_count,
                "destination_city_numeric_like": dest_numeric_like_count,
                "destination_city_special_chars": dest_special_count,
                # class
                "class_invalid": class_invalid_count,
            }

            validation_results = {
                "filepath": filepath,
                "total_rows": total_rows,
                "valid_rows": valid_rows,
                "invalid_rows": invalid_rows,
                "criticality": criticality,
                "errors_summary": errors_summary,
                "error_counts": error_counts,
                "created_on": datetime.now().isoformat(),
                "bad_row_indices": bad_row_indices,
                "validation_status": "PASSED" if invalid_rows == 0 else "FAILED",
                "error_ratio": error_ratio,
                "ge_success": ge_success,
            }

            print("Validation completed:", validation_results)
            return validation_results

        except Exception as e:
            # Only true code/logic errors should reach here
            raise AirflowFailException(f"Validation failed due to error: {str(e)}")

    # 3. Save statistics
    @task(task_id="save_statistics")
    def save_statistics(results: dict) -> None:
        from airflow.providers.postgres.hooks.postgres import PostgresHook
        from airflow.exceptions import AirflowNotFoundException

        conn = None
        cursor = None

        try:
            try:
                hook = PostgresHook(postgres_conn_id=POSTGRES_CONN_ID)
                conn = hook.get_conn()
                cursor = conn.cursor()
            except AirflowNotFoundException:
                # Connection not configured in Airflow → log and SKIP, do not fail DAG
                logging.warning(
                    "Postgres connection 'processed_files' not found. "
                    "Skipping save_statistics. Configure it in Admin → Connections."
                )
                return

            query = """
                INSERT INTO validation_statistics (
                    filepath,
                    total_rows,
                    valid_rows,
                    invalid_rows,
                    criticality,
                    errors_summary,
                    error_counts,
                    created_on,
                    bad_row_indices,
                    error_ratio
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """

            cursor.execute(
                query,
                (
                    results["filepath"],
                    results["total_rows"],
                    results.get("valid_rows", results["total_rows"]),
                    results.get("invalid_rows", 0),
                    results.get("criticality", "low"),
                    results.get("errors_summary", "Validation passed"),
                    json.dumps(results.get("error_counts", {})),
                    results.get("created_on", datetime.now().isoformat()),
                    json.dumps(results.get("bad_row_indices", [])),
                    float(results.get("error_ratio", 0.0)),
                ),
            )
            conn.commit()
            print(f"Statistics saved for {results['filepath']}")

        except Exception as e:
            # Any real DB error
            raise AirflowFailException(f"Database error: {str(e)}")

        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()

    # 4. Alerts + HTML Report (FLIGHT version)
    @task(task_id="send_alerts")
    def send_alerts(results: dict):
        webhook_url = Variable.get("TEAMS_WEBHOOK_URL")
        base_url = Variable.get("GE_DOCS_BASE_URL")
        validation_glob = (
            f"{GE_PATH}/uncommitted/data_docs/local_site/validations/"
            f"{SUITE_NAME}/*/validation_result.html"
        )
        files = glob.glob(validation_glob)
        if files:
            latest = max(files, key=os.path.getmtime)
            relative = os.path.relpath(
                latest, f"{GE_PATH}/uncommitted/data_docs/local_site"
            )
            report_url = f"{base_url}/{urllib.parse.quote(relative.replace('\\', '/'))}"
        else:
            report_url = f"{base_url}/index.html"

        adaptive = {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": {
                        "type": "AdaptiveCard",
                        "version": "1.4",
                        "body": [
                            {
                                "type": "TextBlock",
                                "text": "Flight Data Validation",
                                "weight": "Bolder",
                                "size": "Medium",
                            },
                            {
                                "type": "FactSet",
                                "facts": [
                                    {
                                        "title": "File:",
                                        "value": os.path.basename(results["filepath"]),
                                    },
                                    {
                                        "title": "Rows:",
                                        "value": str(results["total_rows"]),
                                    },
                                    {
                                        "title": "Invalid:",
                                        "value": str(results["invalid_rows"]),
                                    },
                                    {
                                        "title": "Criticality:",
                                        "value": results["criticality"].upper(),
                                    },
                                    {
                                        "title": "Errors:",
                                        "value": results["errors_summary"],
                                    },
                                ],
                            },
                        ],
                        "actions": [
                            {
                                "type": "Action.OpenUrl",
                                "title": "📄 View HTML Report",
                                "url": report_url,
                            }
                        ],
                    },
                }
            ],
        }
        r = requests.post(webhook_url, json=adaptive)
        if r.status_code not in (200, 202):
            logging.error(f"Teams webhook failed: {r.text}")

    # 5. Split into good/bad
    @task(task_id="split_and_save_data")
    def split_and_save_data(results: dict) -> None:
        import pandas as pd

        try:
            df = pd.read_csv(results["filepath"])
            filename = os.path.basename(results["filepath"])

            if results["invalid_rows"] == 0:
                df.to_csv(os.path.join(GOOD_DATA_DIR, filename), index=False)
            elif results["valid_rows"] == 0:
                df.to_csv(os.path.join(BAD_DATA_DIR, filename), index=False)
            else:
                bad_idx = results["bad_row_indices"]
                bad = df.iloc[bad_idx]
                good = df.drop(index=bad_idx)

                good.to_csv(os.path.join(GOOD_DATA_DIR, filename), index=False)
                bad.to_csv(os.path.join(BAD_DATA_DIR, filename), index=False)

            os.remove(results["filepath"])
            print(f"Removed original file: {results['filepath']}")

        except Exception as e:
            raise AirflowFailException(f"Split error: {str(e)}")

    # DAG wiring
    data_file = read_data()
    validation_results = validate_data(data_file)

    data_file >> validation_results >> [
        save_statistics(validation_results),
        send_alerts(validation_results),
        split_and_save_data(validation_results),
    ]


_ingestion_dag = _ingestion_dag()
