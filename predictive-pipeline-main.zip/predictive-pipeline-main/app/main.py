# app/main.py
from fastapi import FastAPI
import logging

from helpers.dbconfig import get_db_pool as init_connection_pool
from businessLogic.predictionBL import load_model
from controllers import predictionController

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)

app = FastAPI(title="Flight Price Prediction API")


@app.on_event("startup")
def startup_event():
    """
    Initialize DB connection pool and load the ML model once at startup.
    If DB init fails, log the error but DO NOT crash the app.
    """
    try:
        init_connection_pool()
        logging.info("DB connection pool initialized successfully.")
    except Exception as e:
        logging.error(f"DB connection pool init failed: {e}")

    load_model()
    logging.info("Startup hook finished.")


app.include_router(
    predictionController.router,
    prefix="/api",
    tags=["prediction"],
)


@app.get("/")
def health_check():
    return {
        "status": "ok",
        "message": "Flight Price Prediction API is running."
    }
