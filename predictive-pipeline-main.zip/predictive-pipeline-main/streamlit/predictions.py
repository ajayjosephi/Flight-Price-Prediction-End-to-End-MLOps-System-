import streamlit as st
import pandas as pd
import requests
import io  

st.set_page_config(page_title="Flight Price Predictor", page_icon="✈️")

st.title("Flight Price Prediction")

# Same API URL as before – backend unchanged
API_URL = "http://fastapi_service:8000/api/predict/"

# USER INPUT
def get_user_inputs():
    airline = st.selectbox("Airline", [
        "SpiceJet", "AirAsia", "Vistara", "Indigo", "GO_FIRST", "Air_India"
    ])

    flight = st.number_input("Flight Number", min_value=100, max_value=9999, step=1, value=1234)

    source_city = st.selectbox("Source City", [
        "Delhi", "Mumbai", "Bangalore", "Chennai", "Kolkata", "Hyderabad"
    ])

    departure_time = st.selectbox("Departure Time", [
        "Early_Morning", "Morning", "Afternoon", "Evening", "Night", "Late_Night"
    ])

    stops = st.selectbox("Number of Stops", [
        "zero", "one", "two_or_more"
    ])

    arrival_time = st.selectbox("Arrival Time", [
        "Early_Morning", "Morning", "Afternoon", "Evening", "Night", "Late_Night"
    ])

    destination_city = st.selectbox("Destination City", [
        "Delhi", "Mumbai", "Bangalore", "Chennai", "Kolkata", "Hyderabad"
    ])

    seat_class = st.selectbox("Class", [
        "Economy", "Business"
    ])

    duration = st.number_input("Flight Duration (hours)", min_value=0.0, step=0.5, value=2.5)

    days_left = st.number_input("Days Left for Travel", min_value=0, step=1, value=30)

    return {
        "airline": airline,
        "flight": flight,
        "source_city": source_city,
        "departure_time": departure_time,
        "stops": stops,
        "arrival_time": arrival_time,
        "destination_city": destination_city,
        "class": seat_class,
        "duration": duration,
        "days_left": days_left,
    }


single_tab, multiple_tab = st.tabs(["Single Prediction", "Multiple Predictions"])


# SINGLE PREDICTION
with single_tab:
    st.subheader("Predict price for a single flight")

    user_data = get_user_inputs()

    if st.button("Predict Price"):
        try:
            # same payload structure as before
            payload = {"data": [user_data]}
            response = requests.post(API_URL, json=payload)

            if response.status_code == 200:
                # CHANGED: backend returns CSV, so parse CSV instead of JSON
                csv_text = response.text
                df_pred = pd.read_csv(io.StringIO(csv_text))

                st.success("Prediction Received Successfully!")

                # show the whole row returned by API (for debugging/inspection)
                st.write(" API response as table:")
                st.dataframe(df_pred)

                if "predicted_price" in df_pred.columns:
                    price = df_pred.loc[0, "predicted_price"]
                    st.metric("Predicted Price", f"₹ {price:,.2f}")
                else:
                    st.warning("Column 'predicted_price' not found in API response.")

            else:
                st.error(f"API Error: {response.status_code}")
                st.text(response.text)

        except requests.exceptions.ConnectionError:
            st.error("API unreachable. Ensure FastAPI service is running.")
        except Exception as e:
            st.error(f"Unexpected Error: {e}")


# MULTIPLE PREDICTIONS
with multiple_tab:
    st.subheader("Bulk Flight Price Predictions")

    uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])

    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file)

            st.write("Uploaded File Preview:")
            st.dataframe(df.head())

            required_cols = [
                "airline", "flight", "source_city", "departure_time",
                "stops", "arrival_time", "destination_city", "class",
                "duration", "days_left"
            ]
            missing = [c for c in required_cols if c not in df.columns]

            if missing:
                st.error(f"Missing required columns: {missing}")

            else:
                if st.button("Run Bulk Prediction"):
                    try:
                        payload = {"data": df.to_dict(orient="records")}
                        response = requests.post(API_URL, json=payload)

                        if response.status_code == 200:
                            # CHANGED: parse CSV returned by backend
                            csv_text = response.text
                            df_pred = pd.read_csv(io.StringIO(csv_text))

                            st.success("Bulk Prediction Completed!")

                            # Show predictions table
                            st.write(" API response with predictions:")
                            st.dataframe(df_pred)

                            # CHANGED: download exactly what backend returns
                            st.download_button(
                                "Download Predictions CSV",
                                csv_text,
                                file_name="flight_price_predictions.csv",
                                mime="text/csv"
                            )
                        else:
                            st.error(f"API Error: {response.status_code}")
                            st.text(response.text)

                    except requests.exceptions.ConnectionError:
                        st.error("API unreachable.")
                    except Exception as e:
                        st.error(f"Unexpected Error: {e}")

        except Exception as e:
            st.error(f"File processing error: {e}")
