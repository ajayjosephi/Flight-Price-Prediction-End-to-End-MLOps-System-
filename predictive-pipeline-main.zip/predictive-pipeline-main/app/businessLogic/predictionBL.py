# app/businessLogic/predictionBL.py
from pathlib import Path
import pandas as pd
import joblib
import logging
from io import StringIO
from fastapi import HTTPException

from databaseLogic.predictionDL import insert_predictions

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE_DIR / "data" / "flight_price_model.pkl"     

model = None  # Global model instance

def load_model():
    """
    Load the ML model from disk into a global variable.
    """
    global model
    try:
        if not MODEL_PATH.exists():                                  
            logging.error("Model file not found at %s", MODEL_PATH)  
            return

        model = joblib.load(MODEL_PATH)
        logging.info("Model loaded successfully from %s", MODEL_PATH)
    except Exception as e:
        logging.exception("Unexpected error while loading model: %s", e)
        return


def make_prediction(df: pd.DataFrame, source: str, background_tasks=None) -> str:
    global model
    if model is None:
        raise HTTPException(status_code=500, detail="Model not loaded.")

    required_cols = [
        "airline",
        "flight",
        "source_city",
        "departure_time",
        "stops",
        "arrival_time",
        "destination_city",
        "class",
        "duration",
        "days_left",
    ]

    # Check for missing columns
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        logging.warning("Missing required columns: %s", missing)
        raise HTTPException(
            status_code=400,
            detail=f"Missing required columns: {missing}",
        )

    # Run model predictions
    try:
        predictions = model.predict(df)
    except Exception as e:
        logging.exception("Error during model.predict: %s", e)
        raise HTTPException(status_code=500, detail="Error during prediction.")

    # Probability handling
    try:
        probabilities = model.predict_proba(df)[:, 1]
    except AttributeError:
        logging.warning("Model does not support predict_proba; setting confidence_score to 1.0")
        probabilities = [1.0] * len(df)
    except Exception as e:
        logging.exception("Error during model.predict_proba: %s", e)
        raise HTTPException(status_code=500, detail="Error during probability estimation.")

    df["predicted_price"] = predictions
    df["confidence_score"] = probabilities

    # DB insert logic
    if source == "Scheduled":
        logging.info("Inserting predictions synchronously for source=%s", source)
        insert_predictions(df, predictions, probabilities, source)
    else:
        if background_tasks is not None:
            logging.info("Queueing async insert_predictions via BackgroundTasks (source=%s)", source)
            background_tasks.add_task(insert_predictions, df, predictions, probabilities, source)
        else:
            logging.warning(
                "background_tasks is None; inserting predictions synchronously (source=%s)",
                source,
            )
            insert_predictions(df, predictions, probabilities, source)

    output = StringIO()
    df.to_csv(output, index=False)
    output.seek(0)
    return output.getvalue()
