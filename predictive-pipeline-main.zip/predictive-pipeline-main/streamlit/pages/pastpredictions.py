import streamlit as st
import pandas as pd
import datetime
import requests

# --- PAGE CONFIG ---
st.set_page_config(
    page_title="Past Predictions",
    page_icon="📊",
    layout="wide"
)

# ---- STYLES ----
st.markdown("""
<style>
/* Page background and font size tweaks */
.main > div {
    padding: 2rem 3rem;
}

/* Card-like container */
.block-container {
    padding-top: 2rem;
}

section {
    background: #1b1e22;
    padding: 25px;
    border-radius: 12px;
    border: 1px solid #2a2d33;
}

.stButton>button {
    border-radius: 8px;
    padding: 0.6rem 1.5rem;
    font-size: 1rem;
}

.dataframe {
    border-radius: 12px !important;
}

</style>
""", unsafe_allow_html=True)

# ---- HEADER ----
st.markdown("## Past Predictions")
st.markdown("<p style='color:gray;margin-top:-10px;'>View and download historical prediction data from the system.</p>", unsafe_allow_html=True)

# ---- FILTER SECTION ----
st.markdown("### Filters")

with st.container():
    st.markdown("<section>", unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1,1,1])

    with col1:
        start_date = st.date_input(
            "Start Date",
            datetime.date.today() - datetime.timedelta(days=30)
        )

    with col2:
        end_date = st.date_input(
            "End Date",
            datetime.date.today()
        )

    with col3:
        source_filter = st.selectbox(
            "Prediction Source",
            ["WebApp", "Scheduled Predictions", "All"]
        )

    st.markdown("</section>", unsafe_allow_html=True)

# API
PAST_PREDICTIONS_API_URL = "http://fastapi_service:8000/api/predict/past_predictions/"


# ---- FETCH DATA ----
st.markdown("###  Results")

if st.button(" Load Past Predictions"):
    try:
        params = {
            "start_date": str(start_date),
            "end_date": str(end_date),
            "source": source_filter
        }

        st.info("Fetching predictions from API...")
        response = requests.get(PAST_PREDICTIONS_API_URL, params=params)

        if response.status_code == 200:
            try:
                data = response.json()
            except ValueError:
                st.error(" API returned invalid JSON.")
                st.text(response.text)
                st.stop()

            # df = pd.DataFrame(data.get("past_predictions", []))
            records = data.get("records", [])          # <- backend key
            df = pd.DataFrame(records)

            if df.empty:
                st.warning("⚠ No predictions found for the selected range.")
            else:
                st.success(" Predictions loaded successfully!")

                st.dataframe(df, use_container_width=True)

                # Metrics
                if "predicted_price" in df.columns:

                    # Price-related metrics
                    avg_price = df["predicted_price"].mean()
                    min_price = df["predicted_price"].min()
                    max_price = df["predicted_price"].max()

                    c1, c2, c3 = st.columns(3)
                    c1.metric("Average Predicted Price", f"₹ {avg_price:,.2f}")
                    c2.metric("Min Predicted Price", f"₹ {min_price:,.2f}")
                    c3.metric("Max Predicted Price", f"₹ {max_price:,.2f}")

                # CSV Download
                csv = df.to_csv(index=False).encode("utf-8")
                st.download_button(
                    "⬇ Download CSV",
                    csv,
                    f"past_predictions_{start_date}_to_{end_date}.csv",
                    "text/csv"
                )

        else:
            st.error(f" API Error {response.status_code}")
            st.text(response.text)

    except requests.exceptions.ConnectionError:
        st.error(" Cannot reach API – ensure FastAPI container is running.")
    except Exception as e:
        st.error(f" Unexpected Error: {str(e)}")
