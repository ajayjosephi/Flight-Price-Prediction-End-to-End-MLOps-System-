# flight_data_gen_split.py

import pandas as pd
import os
from pathlib import Path
import glob

# --- Configuration ---

ERROR_DATA_FOLDER = "airflow/data/error_data"

RAW_DATA_FOLDER = "airflow/data/raw_data"

NUM_FILES = 1000


# --- Helper Function for Splitting ---

def split_by_num_files(df: pd.DataFrame, output_base_dir: str, base_name: str, num_files: int):
    """
    Splits a DataFrame into a specified number of files with a roughly equal number of rows.
    Same logic as your original data_gen_split.py:
      - calculates base chunk size
      - distributes remainder rows among the first chunks
    """
    total_rows = len(df)

    if total_rows < num_files:
        print(
            f"Error: Total rows ({total_rows}) is less than number of files requested ({num_files}). "
            f"Skipping split."
        )
        return

    base_chunk_size = total_rows // num_files
    remainder = total_rows % num_files

    start_idx = 0
    print(
        f"Splitting {total_rows} rows into {num_files} files "
        f"(Base size: {base_chunk_size}, Remainder: {remainder})..."
    )

    for chunk_num in range(num_files):
        current_chunk_size = base_chunk_size + (1 if chunk_num < remainder else 0)
        end_idx = start_idx + current_chunk_size

        chunk = df.iloc[start_idx:end_idx]

        output_file = os.path.join(
            output_base_dir, f"{base_name}_chunk_{chunk_num + 1:04d}.csv"
        )

        chunk.to_csv(output_file, index=False)
        print(f"  Saved: {os.path.basename(output_file)} with {len(chunk)} rows")

        start_idx = end_idx


# --- Main Execution ---

# 1. Ensure the output directory exists
Path(RAW_DATA_FOLDER).mkdir(parents=True, exist_ok=True)

# 2. Read all error-injected flight files
error_files_pattern = os.path.join(ERROR_DATA_FOLDER, "flight_data_with_errors_*.csv")
error_files = sorted(glob.glob(error_files_pattern))

if not error_files:
    print(
        f"CRITICAL ERROR: No error-injected files found in '{ERROR_DATA_FOLDER}'.\n"
        f"Expected pattern: {error_files_pattern}\n"
        f"Make sure you ran your inject_errors_flight.py first."
    )
    raise SystemExit(1)

print("Found error files:")
for f in error_files:
    print(" -", f)

# Concatenate all error files into a single DataFrame
df_list = []
for f in error_files:
    df_list.append(pd.read_csv(f))

df_all = pd.concat(df_list, ignore_index=True)
print(f"\nCombined error dataset shape: {df_all.shape}")

# 3. Perform the split
base_name = "flight"
split_by_num_files(df_all, RAW_DATA_FOLDER, base_name, NUM_FILES)

print("\nFlight Data Generation Complete. Ready for Airflow (data/raw-data).")
